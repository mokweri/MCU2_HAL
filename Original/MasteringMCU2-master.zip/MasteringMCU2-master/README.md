# MasteringMCU2
This repository holds all documents and source codes related to udemy course "Mastering Microcontroller 2: TIMERS, PWM, CAN, RTC,LOW POWER"

you can get the course coupon by clicking the below link
https://www.udemy.com/microcontroller-programming-stm32-timers-pwm-can-bus-protocol/?couponCode=MCU2ONLY10
